READ ME FILE
STEPS To install Jupyter Notebook to run our project, you can follow the instructions below:

Open your terminal and navigate to the mini project directory.
Install python environment & ide.
Install Jupyter Notebook using pip by running the following command: pip install jupyter.
Launch Jupyter Notebook by running the following command: jupyter notebook.
For project file u need to open to NEWLSTM file.
Run all the cell in jupyter notebook.
~mmr